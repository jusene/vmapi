**Deprecated: megacheck has been merged into the staticcheck tool.**
