#!/usr/bin/env python2

def get_none():
    return None

