package data

type Foo struct {
	Field1 string `json:"field1"`
}
